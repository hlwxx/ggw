SET NAMES UTF8;
DROP DATABASE IF EXISTS ggw;
CREATE DATABASE ggw CHARSET=UTF8;
USE ggw;
/*用户信息*/
CREATE TABLE ggw_user(
    uid INT PRIMARY KEY AUTO_INCREMENT,
    uname VARCHAR(32),
    upwd VARCHAR(32),
    email VARCHAR(64),
    phone VARCHAR(16),
    user_name VARCHAR(32), #用户名，如张三
    gener INT     #性别 0-女 1-男
);
/*插入用户信息*/
INSERT INTO ggw_user VALUES(NULL,"dongdong","123456","dong@qq.com","13501234567","小明","1");
