//* 定义二级菜单,参考父级定位 */
$(document).ready(function(){
	
	$(".nav li").mouseenter(function(){
			$(this).addClass("active");
			$(this).children(".sub-nav").fadeIn();//淡入淡出的效果
		}).mouseleave(function(){
			$(this).removeClass("active");
			$(this).children(".sub-nav").fadeOut();//淡入淡出的效果
		});
});
/*<!--main 导航-->*/
$(document).ready(function(){
	
	$(".main_a li").mouseenter(function(){//鼠标移入效果
			$(this).addClass("main_p");
		}).mouseleave(function(){//鼠标移出效果
		$(this).removeClass("main_p");
		});
});







 $(function(){ //形成函数作用域 避免造成全局污染
 //声明一个变量 来放生成的HTML片段
   $.ajax({
	url:"http://localhost:3000/index",
	type:"get",
	dataType:"json"
 })
 .then(function(result){
	  //console.log(result);
	  var html='';
	  //for循环生成多个产品
	  for(var i=0;i<6;i++){
		  var p = result[i];
	   html+=`<div class="product_h6">
					   <div class="product_a">
					  <span><i class="iconfont"></i></span>
						  <a href="#">
							<h6 class="titleC">${p.titleC}</h6>
					   <p class="titleE">${p.titleE}</p>
						  </a>
					  </div>
						   <a href="product_details.html?lid=1"><img src="${p.pic}" alt=""></a>
					 <span class="priceM">${p.priceM}</span>
				 </div>`;
	  }
	  //把生成的HTML片段放回产品列表父元素标签中
	  $("#product").html(html);
 })

});






//轮播图
var swiper = new Swiper('.swiper-banner', {
	    /*间距spaceBetween*/
      spaceBetween: 15,
			/*去掉就是轮播图效果,加上effect:"cube"带点反转的效果*/
			effect:"cube",
      centeredSlides: true,
      autoplay: {
        delay: 3500, ///这个控制自动切换的速度
        disableOnInteraction: false,
      },
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
    });




  
  
  
   