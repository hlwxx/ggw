// 先将弹出提示'成功加入购物车'隐藏
$(function(){
  $("#alt").hide();
});
// 先将弹出提示'收藏成功'隐藏
$(function(){
  $("#collect").hide();
});

//需求一：设置点击加减+-按钮时数量随之改变
    //做所有DOM操作的四步：
    //1.先找到触发事件的所有元素--此处为按钮(先缩小范围再找)
    var btns=document.getElementsByTagName('button');
    
    //console.log(btns); //找到结果是类数组对象
    //2.为元素绑定事件处理函数
      //2-1 遍历类数组对象btns中每个按钮
      for(var btn of btns){
        //每遍历一个按钮 就为其绑定单击事件处理函数
        btn.onclick=function(){
          //所有事件处理函数中的this,永远指.前的当前元素对象--动态获得对应按钮(谁触发事件 this就指向谁) 单击事件发生时，调用为 btn.onclick()
          var btn=this;
          console.log(btn); 
          //优先使用局部变量 要重新声明一个变量(起好理解的别名) 否则会指向全局变量 指向最后一个btn
          //3.查找要修改的元素--数字 放在input中的value='1'
          //查找按钮的 父元素下的 第二个子元素(parentNode  获得元素的父节点)
          //(有相同的爹div 且input永远是爹的第二个儿子 下标为1)
          var input=btn.parentNode.children[1];
          //4.修改元素
          //获得input的value值/数字 变量名为n
          //强调：凡是从页面上获得的都是字符串,做算数计算前必须先转为数字再计算
          // 表单元素的内容，都必须用.value才能获得
          var n=parseInt(input.value);
          //把从页面上获得的数据n放回input.value
          //input.value=n;
          //若btn的内容是+
          if(btn.innerHTML=='+'){
            n++; //n就加1
          }else if(n>0){ //否则 若n的内容>1
            n--; //才能减1
          }
          //最后将修改的n放回input中(按值传递 基本类型是复制副本 所以要把修改的内容放回)
          input.value=n;
          //console.log(n); 
        }
      }

// 需求二:选中规格显示高亮且显示对应价格
  // 2.1先在对应html代码中绑定函数并传参
  //实现购物车选中规格的函数：
  // current为形参 接收实参this
  function specs(current,price){
    var specs = $(".active");
    for(var i=0;i<specs.length;i++){
      // 让之前选中元素添加的类名去掉
      $(specs[i]).removeClass("active");
    }
    // 给当前点中的元素添加类名
    $(current).addClass("active");
    
    // 点击加入购物车弹出div中 选择对应规格显示相应价格：
    document.getElementById('price').innerHTML='￥'+price;
    console.log(price);
  }

  //需求三：点击加入购物车 提示'成功添加购物车'
  function book(){
   $('#alt').show();
    setTimeout(function(){
      $("#alt").hide();
    },1500);
  }


  //需求四：点击收藏按钮 替换图片地址为红心
  // 点击'收藏'弹出div提示'收藏成功' 2秒后自动消失
  var i = 0 ;
  function change(){
      var imgBT = document.getElementById('imgBT') ;
      // console.log(imgBT);
      var collect=document.getElementById('collect');
      // console.log(collect);
      
      if(i == 0){
        imgBT.src = 'images/product_details/05-3.red-heart.png' ;
        i = 1 ;
        $('#collect').show();
        setTimeout(function(){
        $('#collect').hide();
        },1500);
        // alert('收藏成功');
        
      }else{
        imgBT.src = 'images/product_details/05-2.white-heart.png' ;
        i = 0 ;
        alert('是否确定取消收藏?');
      }
  }

//需求五：放大镜效果及点击箭头移动小图片(动态获取数据时 需要在前面多加一步填充图片的操作)
  //5.1 填充左侧图片列表(待有数据时动态获取后填充)

  //5.2点击箭头 移动小图片:
  // 查找左右箭头图片并用变量保存( $(DOM元素) 将已经获得的DOM元素封装为jQuery对象 )
  var $btnLeft=$('#btn-left');
  var $btnRight=$('#btn-right');
  // 查找父元素ul-imgs 用来放小图片
  var $ulImgs=$('#ul-imgs');
  // 定义变量保存每个li的宽度 反复使用
  var LIWIDTH=62;
  // 设置ming的src为数据库中pics数组为第一张图片的中图片版本
  var $mImg=$('#ming');
  var $lgDiv=$('#div-lg');

  // 用数组来存放图片本地地址(后期改为从数据库中获取)
  var pics = [{sm:'images/product_main/sm/01.sm-pic-1.jpg',
              md:'images/product_main/md/02.md-pic-1.jpg',
              lg:'images/product_main/lg/03.lg-pic-1.jpg'},
              {sm:'images/product_main/sm/01.sm-pic-2.jpg',
              md:'images/product_main/md/02.md-pic-2.jpg',
              lg:'images/product_main/lg/03.lg-pic-2.jpg'},
              {sm:'images/product_main/sm/01.sm-pic-3.jpg',
              md:'images/product_main/md/02.md-pic-3.jpg',
              lg:'images/product_main/lg/03.lg-pic-3.jpg'},
              {sm:'images/product_main/sm/01.sm-pic-4.jpg',
              md:'images/product_main/md/02.md-pic-4.jpg',
              lg:'images/product_main/lg/03.lg-pic-4.jpg'},
              {sm:'images/product_main/sm/01.sm-pic-5.jpg',
              md:'images/product_main/md/02.md-pic-5.jpg',
              lg:'images/product_main/lg/03.lg-pic-5.jpg'}
            ];
  // 设置默认显示的中图片
  $mImg.attr('src',pics[0].md);

  // 同时为lgDiv设置背景图片为第一张的lg版本
  $lgDiv.css('background-image',`url(${pics[0]}.lg)`);

  // 若pics的图片数量一开始就<=4张 则一开始就禁用右边按钮
  var img_length=$('.img_box img').length;
  if(img_length<=4){
    $btnRight.addClass('disabled');
  }
  // 声明一个变量来记录单次点击的次数
  var times=0;
  // 右边按钮每单击一次 则times+1 重新计算$ulImgs的左边距marginLeft
  $btnRight.click(function(){
    // 若右边按钮上的类名不是.disabled 则次数times自增
    if(!$btnRight.is('.disabled')){
      times++;
      // 获取或修改一个CSS属性的值
      //elem.style.css属性 -> $元素.css('属性名'[,'属性值'])
      //点右边按钮左移62px
      $ulImgs.css('margin-left',-times*LIWIDTH);
      //只要右边按钮能点一下 左边按钮一定启用
      $btnLeft.removeClass('disabled');
      // 若times==pics(数据库中图片张数)-4 说明多余图片都移动完了 就禁用右边按钮
      if(times==img_length-4){
        $btnRight.addClass('disabled');
      }
    }
  });
  // 左边按钮： 每单击一次 则times-1 重新计算$ulImgs的marginLeft
  $btnLeft.click(function(){
    if(!$btnLeft.is('.disabled')){
      times--;
      // 放图片的父元素整体左移 第5个图片从后面补位 显示在最后一个的位置
      $ulImgs.css('margin-left',-times*LIWIDTH);
      // 只要左边按钮可以点过一下 则右边按钮一定启用
      $btnRight.removeClass('disabled');
      // 若times=0 则左边按钮禁用
      if(times==0){
        $btnLeft.addClass('disabled');
      }
    }
  });

  //5.3 鼠标进入小图片 切换中图片：
  // 事件委托 为父元素绑定鼠标进入事件 但是只有进入img时才触发
  $ulImgs.on('mouseenter','li>img',function(){
    // 获得当前图片的data-md属性 并赋值给$mImg的src
    $mImg.attr('src',$(this).attr('data-md'));
    // 同时获得当前大图片的data-lg属性，给$lgDiv做背景图片
    $lgDiv.css('background-image',`url(${$(this).attr('data-lg')})`
    );
  });

  // 5.4当鼠标进出透明层div时 切换小遮罩层的显示和隐藏：
  var $mask=$('#mask');
  var $smask=$('#super-mask');
  var MSIZE=176;//记录小mask的大小
  var SMSIZE=352;//记录super-mask的大小

  $smask.hover(function(){
    // 在有或没有这个class之间来回切换时，用toggleClass() 
    $mask.toggleClass('d-none');
    // 同时显示大div
    $lgDiv.toggleClass('d-none');
  }).mousemove(function(e){// 让遮罩层随着鼠标移动
    // 红=绿-蓝
    var top=e.offsetY-MSIZE/2;
    var left=e.offsetX-MSIZE/2;
    // 若top<0 就拉回0;若top>SMSIZE-MSIZE就拉回SMSIZE-MSIZE
    if(top<0){
      top=0;//重新赋值为0
    }else if(top>SMSIZE-MSIZE){
      top=SMSIZE-MSIZE;
    }
    // 若left<0 就拉回0;若left>SMSIZE-MSIZE就拉回SMSIZE-MSIZE
    if(left<0){
      left=0;//重新赋值为0
    }else if(left>SMSIZE-MSIZE){
      left=SMSIZE-MSIZE;
    }
    $mask.css({
      top:top+'px',
      left:left+'px'
    })
    // 同时要修改$lgDiv的背景图片位置
    $lgDiv.css('background-position',`${-left*16/7}px ${-top*16/7}px`);
    // 大图片尺寸(800px) 16
    // 小图片尺寸(800px) 7
  });

  // 5.5鼠标进入上层中图片 显示大图片 大图片背景图片跟随鼠标移动(写在上面了)

// 需求六：横向平移的轮播图(手写)
  // 6.1定义数组保存轮播图对象的图片地址及标题并填充到HTML代码段中
  var carousals=[
    {pic_url:'images/product_details/00.main-pic.jpg',title:'樱花女神芝士蛋糕'},
    {pic_url:'images/product_details/06.recommend-pic.jpg',title:'时尚女神慕斯蛋糕'},
    {pic_url:'images/product_details/07.recommend-pic.jpg',title:'猪小福芝士蛋糕'},
    {pic_url:'images/product_details/08.recommend-pic.jpg',title:'欢乐颂翻糖蛋糕'},
    {pic_url:'images/product_details/09.recommend-pic.jpg',title:'告白情书小熊蛋糕'},
  ];
  //声明一个变量 来放生成的HTML片段
  var html='';
  // 6.2循环遍历数组
  for(var pic of carousals){
    html+=`
    <li class="float-left">
      <div class="card mb-1 p-4 border-0 bg-transparent box-shadow">
        <img src="`+pic.pic_url+`" class="card-img-top" data-src="holder.js/100px225?theme=thumb&amp;bg=55595c&amp;fg=eceeef&amp;text=Thumbnail" alt="Thumbnail [100%x225]" data-holder-rendered="true">
        <div class="card-body p-0">
          <p class="card-text text-center small">`+pic.title+`</p>
        </div>
      </div>
    </li>
    `;
  }
  //把生成的HTML片段追加到父元素标签中(追加 不会覆盖前面的div)
  $('#parent_ul').append(html);

  // 定义一个变量 来保存每个图片外面li的宽度
  var imgWidth=220;

  // 6.3定义一个定时器，每1.5秒执行一次
  var timer=setInterval(function(){
    // 6.4.1执行向左移动一个图片的位置(通过设置左边距 左移第一个图片 会隐藏 显示下一个)
    $('ul#parent_ul li:first')[0].style.marginLeft=-1*imgWidth+"px";
    // 6.4.2删除第一个li标签(防止左边图片堆积)
    $('ul#parent_ul li:first')[0].remove();
    //6.4.3把下一个图片放到最后一个位置(通过判断最后一个是哪个下标i的图片 下一个就是i+1 添加元素)
    // 最后一个图片的下标i=arr.length-1
    // 声明一个变量 保存最后一个位置的标题
    var last_title=$('ul#parent_ul li:last p')[0].innerHTML;
    // 遍历数组 拿出数组中的元素 确定最后一个位置的是哪个

    // 定义一个变量 保存新添加的li
    var li='';
    for(var i=0;i<carousals.length;i++){
      if(last_title==carousals[i].title){//若相等
        // 判断当前最后一个位置的下标
        if(i==carousals.length-1){//若当前最后一个下标是数组中的最后一个
          // 获取数组中的第一个li代码段
          li+=`
          <li class="float-left">
          <div class="card mb-1 p-4 border-0 bg-transparent box-shadow">
            <img src="`+carousals[0].pic_url+`" class="card-img-top" data-src="holder.js/100px225?theme=thumb&amp;bg=55595c&amp;fg=eceeef&amp;text=Thumbnail" alt="Thumbnail [100%x225]" data-holder-rendered="true">
            <div class="card-body p-0">
              <p class="card-text text-center small">`+carousals[0].title+`</p>
            </div>
          </div>
        </li>
          `;
        // 结束当前循环
        }else{//若当前最后一个位置不是数组中的最后一个 
          // 则把数组中的下一个li 放到轮播图最后
          li+=`
          <li class="float-left">
          <div class="card mb-1 p-4 border-0 bg-transparent box-shadow">
            <img src="`+carousals[i+1].pic_url+`" class="card-img-top" data-src="holder.js/100px225?theme=thumb&amp;bg=55595c&amp;fg=eceeef&amp;text=Thumbnail" alt="Thumbnail [100%x225]" data-holder-rendered="true">
            <div class="card-body p-0">
              <p class="card-text text-center small">`+carousals[i+1].title+`</p>
            </div>
          </div>
        </li>
          `;
        // 结束当前循环
        }
      }
    }
    
    // 6.4.4 在第最后一个图片后面在追加一个li标签
    $('ul#parent_ul').append(li);
  },2000);

// 需求七：点击'商品详情'或'商品评价'出现对应内容
  // 7.1查找触发事件的元素(此处为两个按钮button)
  var btns=document.querySelectorAll('div#details_judge button');
  // console.log(btns); //查找的结果是类数组对象

  // 7.2为元素绑定事件处理函数(参考 设置点击加减+-按钮时数量随之改变)
  // 遍历类数组对象btns中每个按钮
  for(var btn of btns){
    // 每遍历一个按钮 就为其绑定单击事件处理函数
    btn.onclick=function(){
      // 所有事件处理函数中的this永远指向.前的对象
      // 动态获得对应按钮(谁触发事件 this就指向谁) 单击事件发生时，调用为 btn.onclick()
      var btn=this;//起别名
      // console.log(btn);
      // 7.3查找要修改的元素(点击'商品详情'显示详情内容;点击'商品评价'显示评价内容)
      var detailsImg=document.getElementById('details-img');
      var comments=document.getElementById('comments');
      console.log(detailsImg);
      console.log(comments);

      // 若点击'商品详情' 则显示详情内容 评价内容则不显示 
      if(btn.innerHTML=='商品详情'){
        detailsImg.style.display='block';
        comments.style.display='none';
        btn.style.backgroundColor='#E0BF9A';//当前点中的详情按钮添加背景色
        btns[1].style.backgroundColor='#fff';//未被点中的评价按钮去除背景色

      //若点击'商品评价' 则显示评价内容 详情内容则不显示 
      }else if(btn.innerHTML=='商品评价'){
        detailsImg.style.display='none';//详情内容则不显示 
        comments.style.display='block';//显示评价内容
        btn.style.backgroundColor='#E0BF9A';//当前点中的评价按钮添加背景色
        btns[0].style.backgroundColor='#fff';//未被点中的详情按钮去除背景色
      } 
    }
  }


  







  








  

