function register(){
    //dom操作获取数据
        var u_uname=uname.value;
        var u_pwd=upwd.value;
        var c_pwd=cpwd.value;
        var u_phone=phone.value;
        //1.创建xhr异步对象
        var xhr=new XMLHttpRequest();
        //监听响应获取数据
        xhr.onreadystatechange=function(){
            if(xhr.readyState==4&&xhr.status==200){
                var result=xhr.responseText;
                if(result==1&&u_pwd==c_pwd){
                    alert("注册成功");
                 // location.href="http://127.0.0.1:8080/04_ex.html";
                }else{
                    alert("用户名已被占用");
                }
            
            }
        
        }
        //2.创建请求，打开连接
         xhr.open("post","http://127.0.0.1:3000/pro/reg",true);
        //设置请求头消息
        var formdata="uname="+u_uname+"&upwd="+u_pwd+"&phone="+u_phone;
        xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
        //3.发送请求
        xhr.send(formdata);
}