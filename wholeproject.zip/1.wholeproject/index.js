//  $(function(){
//      $.ajax({
//         url:"http://localhost:3000/index",
//        type:"get",
//          dataType:"json"
//      })
//     .then(function(result){
//         console.log(result);
        
//      })
//  })


// $(function(){ //形成函数作用域 避免造成全局污染
//     //声明一个变量 来放生成的HTML片段
//       $.ajax({
//        url:"http://localhost:3000/index",
//        type:"get",
//        dataType:"json"
//     })
//     .then(function(result){
//          console.log(result);
//          var html='';
//          //for循环生成多个产品
//          for(var i=0;i<6;i++){
//              var p = result[i];
//               html+=`<div class="product_h6">
//                           <div class="product_a">
//                          <span><i class="iconfont"></i></span>
//                              <a href="#">
//                                <h6 class="titleC">${p.titleC}</h6>
//                           <p class="titleE">${p.titleE}</p>
//                              </a>
//                          </div>
//                               <a href="product_details.html?lid=${p.lid}"><img src="${p.pic}" alt=""></a>
//                         <span class="priceM">${p.priceM}</span>
//                     </div>`;
//          }
//          //把生成的HTML片段放回产品列表父元素标签中
       
//          $("#product").html(html);
         
//     })
    
//    })
   