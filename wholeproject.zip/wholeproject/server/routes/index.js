const express=require("express");
const router=express.Router();
const pool=require("../pool.js");

router.get("/",(req,res)=>{
    var sql=`SELECT * FROM ggw_product where seq_recommended!=0 order by seq_recommended`
    pool.query(sql,[],(err,result)=>{
        if (err){
            console.log(err);
            res.send({code:0});
        }else{
            res.send(result);
        }
    })
})
//导出          路由器
module.exports=router;