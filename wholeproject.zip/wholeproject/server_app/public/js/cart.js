// 删除所选全部物品的函数:
function removeDivs(){
  if(chb.checked==false){
    alert('请选择商品');
  }else{
    if(window.confirm('是否确认删除所选商品?')){
      var divs=document.querySelectorAll('#cart-items>div');//设为局部变量
      //属性选择器input[type=checkbox]'
      var checkBoxs=document.querySelectorAll('#cart-items>div input[type=checkbox]');
      // 循环遍历出所有选中的商品并删除这些元素
      for(var i=0;i<divs.length;i++){
        if(checkBoxs[i].checked){
          document.querySelector('#cart-items').removeChild(divs[i]);
        }
      }
    }
  }
  //调用自定义函数 总数和总价格函数刷新
  sumCount();
}

// 删除单个物品的函数：
function removeThing(evt){
    if(window.confirm('是否确认删除此商品?')){
      var divs = document.querySelectorAll('#cart-items>div');//设为局部变量
      var thing = evt.target||evt.srcElement;
      document.querySelector('#cart-items').removeChild(thing.parentNode.parentNode);
    }
    sumCount();
 }

// 调整数量加减的函数：//前一个兄弟元素 previousElementSibling   
 function changeCount(evt){
    var operator = evt.target||evt.srcElement;
    if(operator.textContent == '+'){
      if(operator.previousElementSibling.value <= 999){
        operator.previousElementSibling.value = parseInt(operator.previousElementSibling.value) + 1;
      }
     //console.log(operator.previousElementSibling);
      }else{ //下一个兄弟元素 nextElementSibling
        if(operator.nextElementSibling.value >= 2){
          operator.nextElementSibling.value = parseInt(operator.nextElementSibling.value) - 1;
        }
      }

  //查找元素
  // 查找获得的父元素 parentElement
  var price = operator.parentElement.parentElement.querySelector('.price');
  var countIput=operator.parentElement.querySelector('input').value;
  if(countIput>999||countIput<1){
    window.alert('请输入有效数字');
    return;
  }
  // 获取或设置元素开始标签到结束标签之间的纯文本内容: 元素.textContent
  var newPrice = parseInt(price.textContent) * parseFloat(countIput);
  //toFixed函数保留两位小数
  operator.parentElement.nextElementSibling.querySelector('span').innerHTML = newPrice.toFixed(2); 
  sumCount();
}

// 总数和总价格刷新函数：
function sumCount(){
  var divs=document.querySelectorAll('#cart-items>div');
  var count=0;//初始化总的数量为0
  var sumPrice=0;//初始化总价为0
  for(var i=0;i<divs.length;i++){
    if(divs[i].querySelector('input[type=checkbox]').checked){
      count+=parseInt(divs[i].querySelector('input[type=text]').value);
      sumPrice += parseInt(divs[i].querySelector('.priceCount').innerHTML);
    }
  }
  document.querySelector('#totalCount').innerHTML=parseInt(count);//总数成功改变
  document.querySelector('#totalPrice').innerHTML='￥'+sumPrice.toFixed(2);//总的价格改变
}

//全选的函数：
function allIn(){
  //var allBtn = evt.target||evt.srcElement;
  var checkBoxs = document.querySelectorAll('#cart-items>div input[type=checkbox]');
  if(qxButton.checked){   //如果全选按钮没按
    for(var i = 0;i < checkBoxs.length;i++){
      if(!checkBoxs[i].checked){
         checkBoxs[i].checked = true; //
      }
    }
  }else{   //如果不是全选，就变为全选
    for(var i = 0;i < checkBoxs.length;i++){
      if(checkBoxs[i].checked){
        checkBoxs[i].checked = false;  
      }
    }
  }    
    sumCount();
  }

// 删除所选物品:
var removeDiv=document.getElementById('clearSelected');
// 添加事件监听对象("事件名",处理函数)
removeDiv.addEventListener('click',removeDivs);
// 删除单个指定商品
var removeThings=document.querySelectorAll('#cart-items>div .center>a');
for(var i=0;i<removeThings.length;i++){
  removeThings[i].addEventListener('click',removeThing);
}
// 数量加减按钮 数量变化导致价格变化
var countButtons=document.querySelectorAll('#cart-items>div .small-button');
for(var i=0;i<countButtons.length;i++){
  countButtons[i].addEventListener('click',changeCount);
}
// 数量输入框自己输入
var inputBorders=document.querySelectorAll('#cart-items>div>div input[type=text]');
for(var i=0;i<inputBorders.length;i++){
  inputBorders[i].addEventListener('click',changeCount);
}
// 总数量以及总计价格功能
var checkBoxs = document.querySelectorAll('#cart-items>div input[type=checkbox]');
    for(var i = 0;i < checkBoxs.length;i++){
      checkBoxs[i].addEventListener('click', sumCount);
    }
// 全选按钮
var qxButton=document.getElementById('selectAll');
qxButton.addEventListener('click',allIn);

// cart.js 待解决的问题：
//全选和反选功能(点全选则选中全部，再点一次则全部取消；去掉单个则取消全选 全部选中则全选按钮也被选中)
//未选中商品就点删除 提示'请选择商品后再删除'

//需求二：点下边的所有的checkbox,都有可能影响上边的chbAll全选按钮
//(选中或取消下面的按钮 上面的全选也要随之变化)
//做所有DOM操作的四步：
//1.先找到触发事件的所有元素
// 找到上面的全选按钮
var chbAll=document.getElementById('selectAll');
// console.log(chbAll);
// 找到下面所有的input
var chbs=document.querySelectorAll('input[type=checkbox]');
// console.log(chbs);

//2.为元素绑定事件处理函数
//遍历chbs中每个chb
for(var chb of chbs){
  chb.onclick=function(){ //内层函数
    //3.查找要修改的元素(直接使用上面外部查找过的chbAll)
    //4.修改元素 先获得当前chb
    var chb=this;
    //若当前chb取消选中
    if(chb.checked==false){
      //则chbAll一定不全选(赋值用一个等号)
      chbAll.checked=false;
    }else{
      //先找到下面一个未被选中input(未找到为空)
      var unchecked=document.querySelector('div#cart-items input[type=checkbox]:not(:checked)');
      console.log(unchecked);
      //若找不到未选中的chb了
      if(unchecked==null){
        //才全选(全选按钮被选中)
        chbAll.checked=true;
      }
    }
  }
}
