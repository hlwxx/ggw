SET NAMES UTF8;
DROP DATABASE IF EXISTS ggw;
CREATE DATABASE ggw CHARSET=UTF8;
USE ggw;
/*用户信息*/
CREATE TABLE ggw_user(
    uid INT PRIMARY KEY AUTO_INCREMENT,
    uname VARCHAR(32),
    upwd VARCHAR(32),
    email VARCHAR(64),
    phone VARCHAR(16),
    user_name VARCHAR(32), #用户名，如张三
    gener INT     #性别 0-女 1-男
);
/*插入用户信息*/
INSERT INTO ggw_user VALUES(NULL,"dongdong","123456","dong@qq.com","13501234567","小明","1");

/*首页商品列表*/
CREATE TABLE ggw_product(
    lid INT PRIMARY KEY AUTO_INCREMENT,  
    titleC VARCHAR(128),    /*名称*/
    titleE VARCHAR(128),   /*详情*/
    pic VARCHAR(128),      /*照片*/
    priceM DECIMAL(10,2),   /*价格*/
    href VARCHAR(128),     /*超链接*/
    seq_recommended TINYINT,  /*推荐*/
    seq_new_arrival TINYINT, /*是否有货*/
    seq_top_sale TINYINT  /*是否在销*/
);

INSERT INTO ggw_product VALUES
(NULL,'樱花女神芝士蛋糕','樱花女神:六寸','images/products/01.products_img.jpg',299,'product_details.html?lid=1',10,10,10),
(NULL,'时尚女神慕斯蛋糕','时尚女神:七寸','images/products/02.products_img.jpg',299,'product_details.html?lid=2',20,20,20),
(NULL,'猪小福芝士蛋糕','猪小福:六寸','images/products/03.products_img.jpg',299,'product_details.html?lid=3',30,30,20),
(null,'欢乐颂翻糖蛋糕','欢乐颂:六寸','images/products/04.products_img.jpg',399,'product_details.html?lid=4',10,10,10),
(NULL,'网红爆浆蛋糕','爆浆蛋糕:六寸','images/products/05.products_img.jpg',199,'product_details.html?lid=5',10,10,10),
(null,'告别情书小熊蛋糕','告白情书小熊蛋糕:六寸','images/products/06.products_img.jpg',299,'product_detailes.html?lid=6',10,20,30)
