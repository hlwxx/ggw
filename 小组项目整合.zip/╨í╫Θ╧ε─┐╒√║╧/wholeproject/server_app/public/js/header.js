
$(function(){
    $.ajax({
        url:"header.html",
        type:"get",
        success:function(result){
            $(result).replaceAll("header");
            $(`<link rel="stylesheet" href="css/header.css">`).appendTo("head")
        }
    })
})
$(document).ready(function(){
	$(".nav li").mouseenter(function(){
			$(this).addClass("active");
			$(this).children(".sub-nav").fadeIn();//淡入淡出的效果
		}).mouseleave(function(){
			$(this).removeClass("active");
			$(this).children(".sub-nav").fadeOut();//淡入淡出的效果
		});
});
