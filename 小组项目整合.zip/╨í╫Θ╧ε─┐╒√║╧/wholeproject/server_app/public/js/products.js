//全局变量details 用来保存整个div
var details;

$(function(){ //形成函数作用域 避免造成全局污染
  //声明一个变量 来放生成的HTML片段
  var html='';
  //for循环生成多个产品

  for(var i=0;i<27;i++){//代码段
    html+=`<div class='col-md-4 p-1'>
              <div class='card mb-4 box-shadow pr-2 pl-2 img1'>
                <a href='product_details.html?lid=1'>
                  <img class='card-img-top' src='images/products/01.products_img.jpg' alt=''>
                  <div></div>
                </a>
                <div class='card-body' p-0>
                  <h5>￥`+(i+100)+`</h5>
                  <p class='card-text'>
                    <a href='product_details.html?lid=1' class='text-muted small' title='樱花女神芝士蛋糕'>樱花女神芝士蛋糕
                      <br>
                      <span>尺寸：6寸</span>
                    </a>
                    
                    </p>
                  <div class='d-flex justify-content-between align-items-center p-2 pt-0' class="data">
                    <button class='btn btn-light p-0 border-0 btn-block' type='button'>-</button>
                    <input type='text' class='form-control p-1' value='1'>
                    <button class='btn btn-light p-0 border-0 btn-block' type='button'>+</button>

                    <!--加入购物车html代码 -->  
                    <div class='spec-details'>
                      <div class='spec-title'>￥100.00</div>
                      <div class='spec-info'>
                        <a class="specs" onclick="specs(this,'100');">1.0磅</a>
                        <a class="specs" onclick="specs(this,'110');">2.0磅</a>
                        <a class="specs" onclick="specs(this,'120');">3.0磅</a>
                        <a class="specs" onclick="specs(this,'130');">4.0磅</a>
                      </div>
                      <div class='buttons'>
                        <button class='buy-now'>立即购买</button>
                        <button class='add-cart'>加入购物车</button>
                      </div>
                    </div>

                     <a class='btn btn-secondary float-right ml-1 pl-1 add' href='javascript:;' style='background-color:#e0bf9a;border:1px solid #e0bf9a;'>加入购物车</a>
                  </div>
                </div>
              </div>
            </div>`;
  }
  //把生成的HTML片段放回产品列表父元素标签中
  $("#plist").html(html);


    //设置点击'加入购物车'的点击事件--做所有DOM操作的四步：
		 //1.查找触发事件的所有元素(点击前的'加入购物车'a标签)
		 var add=document.getElementsByClassName('add');
     //全局变量details 用来保存整个div
		 details=document.getElementsByClassName('spec-details');
     //2.为元素绑定事件处理函数
     for(var i=0;i<add.length;i++){
      add[i].onclick=function(e){
        //点击当前产品的加入购物车 隐藏所有显示的加入购物车的div
        hideSpec();//调用已封装的自定义方法
        //取消冒泡
        e.stopPropagation();
        //3.查找要修改的元素
        //4.修改元素
        if(this.parentNode.childNodes[9].style.display='none'){
          //点击当前产品的加入购物车 显示当前产品加入购物车的div
          this.parentNode.childNodes[9].style.display='block';

          //清除之前选中规格的缓存
          var specs = $(".active");
          for(var i=0;i<specs.length;i++){
            $(specs[i]).removeClass("active");
          }
          //获取当前弹框第一个规格 设置为选中状态(加了边框样式)
          var firstNode=this.parentNode.querySelector('div.spec-info>a.specs:first-child');
          //默认选中第一个
          $(firstNode).addClass("active");
        }
       }
        //点击空白处 隐藏整个div		
        window.onclick=function(event){
          //变量el为当前鼠标点中的元素
           var el = event.target;
           //若选中元素的类名为弹出div中的某一个 则点击空白处不让弹出div隐藏
            if("spec-details"==el.className||"spec-title"==el.className||"spec-info"==el.className||"specs"==el.className
              ||"specs active"==el.className||"buttons"==el.className){
              //若选中元素是 按钮'加入购物车'  
            }else if("add-cart"==el.className){
              book(); //调用自定义方法book显示'成功加入购物车'
              hideSpec(); //则隐藏弹出的div
            }else if("buy-now"==el.className){
              //点'立即购买' 跳转到购物车页面(在products.html 跳转同级目录下的cart.html)
              location.href='./cart.html';
            }else{
              hideSpec(); //点击其余空白处 则隐藏弹出div
            }
        }
     }
		 

  //需求：设置点击加减+-按钮时数量随之改变：
    //做所有DOM操作的四步：
    //1.先找到触发事件的所有元素--此处为按钮(先缩小范围再找)
    //循环出来有多个 所以要用类名 而不能用唯一的id
    // var div=document.getElementsByClassName('data');
    var btns=document.getElementsByTagName('button');
    //console.log(div);
    //console.log(btns); //找到结果是类数组对象
    //2.为元素绑定事件处理函数
      //2-1 遍历类数组对象btns中每个按钮
      for(var btn of btns){
        //每遍历一个按钮 就为其绑定单击事件处理函数
        btn.onclick=function(){
          //所有事件处理函数中的this,永远指.前的当前元素对象--动态获得对应按钮(谁触发事件 this就指向谁) 单击事件发生时，调用为 btn.onclick()
          var btn=this;
          console.log(btn); 
          //优先使用局部变量 要重新声明一个变量(起好理解的别名) 否则会指向全局变量 指向最后一个btn
          //3.查找要修改的元素--数字 放在input中的value='1'
          //查找按钮的 父元素下的 第二个子元素(parentNode  获得元素的父节点)
          //(有相同的爹div 且input永远是爹的第二个儿子 下标为1)
          var input=btn.parentNode.children[1];
          //4.修改元素
          //获得input的value值/数字 变量名为n
          //强调：凡是从页面上获得的都是字符串,做算数计算前必须先转为数字再计算
          // 表单元素的内容，都必须用.value才能获得
          var n=parseInt(input.value);
          //把从页面上获得的数据n放回input.value
          //input.value=n;
          //若btn的内容是+
          if(btn.innerHTML=='+'){
            n++; //n就加1
          }else if(n>0){ //否则 若n的内容>1
            n--; //才能减1
          }
          //最后将修改的n放回input中(按值传递 基本类型是复制副本 所以要把修改的内容放回)
          input.value=n;
          //console.log(n); 
        }
      }
      
  });


  //实现购物车选中规格的函数：
  function specs(current,price){
    var specs = $(".active");
    for(var i=0;i<specs.length;i++){
      // 让之前选中元素添加的类名去掉
      $(specs[i]).removeClass("active");
    }
    // 给当前点中的元素添加类名
    $(current).addClass("active");
    
    // 点击加入购物车弹出div中 选择对应规格显示相应价格：
    current.parentNode.parentNode.querySelectorAll('div.spec-details>div.spec-title')[0].innerHTML='￥'+price;
    console.log(price);
  }

// 右侧垂直轮播图样式:
  (function(ul, delay, speed, lineHeight) {
    var slideBox = (typeof ul == 'string')?document.getElementById(ul):ul;
    var delay = delay||1000;
    var speed=speed||15;
    var lineHeight = lineHeight||60;
    var tid = null, pause = false;
    var start = function() {
      tid=setInterval(slide, speed);
    }
    var slide = function() {
      if (pause) return;
      slideBox.scrollTop += 2;
      if (slideBox.scrollTop % lineHeight == 0) {
        clearInterval(tid);
        slideBox.appendChild(slideBox.getElementsByTagName('li')[0]);
        slideBox.scrollTop = 0;
        setTimeout(start, delay);
      }
    }
    slideBox.onmouseover=function(){pause=true;}
    slideBox.onmouseout=function(){pause=false;}
    setTimeout(start, 2000);
  })
  //停留时间，相对速度（越小越快）,每次滚动多少，最好和Li的Line-height一致
  ('IssueList', 3000, 2, 58);

  //点击加入购物车 提示'成功添加购物车':
  function book(){
      //获取鼠标在屏幕中水平位置
     var x = window.event.clientX + document.body.scrollLeft - document.body.clientLeft;
      //获取鼠标在屏幕中垂直位置
     var y = window.event.clientY + document.body.scrollTop - document.body.clientTop;
     $('#myModal').modal('show');
     //此处减100 位弹框的宽度的一半，确保鼠标在弹框的横向的中心
     $('#myModal')[0].style.left=(x-100)+'px';
      //此处减70 弹框的高度为40，确保鼠标在弹框的下方
     $('#myModal')[0].style.top=(y-70)+'px';
     //定位弹出的div
      setTimeout(function(){
        $("#myModal").modal("hide")
      },2000);
    }

//封装隐藏所有规格弹框(hideSpec自定义方法名)
function hideSpec(){
  for(var i=0;i<details.length;i++){
      details[i].style.display='none';
  }
}


