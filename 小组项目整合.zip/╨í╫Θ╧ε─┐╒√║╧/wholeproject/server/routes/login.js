//引入第三方模块
const express=require('express');
//引入连接池对象
const pool=require("../pool.js");
//使用express模块创建路由器对象
var router=express.Router();
//用户登录
 router.post('/login',(req,res)=>{
     //获取post请求的数据
     var $uname=req.body.uname;
     var $upwd=req.body.upwd;
     //console.log(obj);
     //判断用户名是否为空
     if(!$uname){
        res.send("没有获取到用户名称");
         return;//阻止程序往后执行
     }
     if(!$upwd){
        res.send("没有获取到用户密码");
        return;
     }
    //执行SQL语句
    //查询用户表是否含有用户名和密码同时匹配的数据
    var sql="select * from ggw_user where uname=? and upwd=?";
    pool.query(sql,[$uname,$upwd],(err,result)=>{
        if(err) throw err;
        //console.log(result);
        //判断数组的长度是否大于0
        if(result.length>0){
            res.send("1");
        }else{
            res.send("用户名或密码错误");
        }
    });
 });

 //用户注册
 router.post('/reg',function(req,res){
	//获取post请求的数据
	var $uname=req.body.uname;
	var $upwd=req.body.upwd;
	
	var $phone=req.body.phone;
	

	//验证数据是否为空(不需要验证uid是否为空)
	if(!$uname){
		res.send('用户名未接收到');
		return;
	}
	if(!$upwd){
		res.send('密码未接收到');
		return;
	}

	if(!$phone){
		res.send('手机号未接收到');
		return;
	}
	//执行SQL语句-1(查询是否有已存在的用户名)
	var search_sql='select * from ggw_user where uname=?';
	pool.query(search_sql,[$uname],function(err,result){
		if(err) throw err;

		//判断是否查询到对应用户名
	if(result.length>0){
		res.send('用户名重复 请重新输入');
	}else{
		//执行SQL语句-2(插入新的注册数据)
		var sql="insert into ggw_user set uname=?,upwd=?,phone=? ";
		//	 对象形式的写法 可改写成数组
		pool.query(sql,[$uname,$upwd,$phone],(err,result)=>{
				if(err) throw err;
				//console.log(result);
				//判断是否注册成功 若注册成功响应一个对象
				if(result.affectedRows>0){
					res.send("1");
				   }else{
					res.send("0");
				   }
		
			});
	//post请求无法在地址栏验证 
	};

	});

});

 //导出路由器对象
module.exports=router;