//引入第三方模块
const express=require("express");
//引入路由器
var loginRouter=require("./routes/login.js")
//引入body-parser用post的时候会用到
const bodyParser=require('body-parser');
//运用cors解决跨域问题
const cors=require("cors");
//创建web服务器
var server=express();
//设置监听端口
server.listen(1000);
server.use(cors({
  origin:"http://127.0.0.1:5500"
}))
//托管静态资源到public下
server.use(express.static('public'));
//使用body-parser中间件，将post请求的数据格式化为对象
server.use( bodyParser.urlencoded({
    extended:false
  }) );
//使用路由器
//挂载url:/login
server.use("/pro",loginRouter);